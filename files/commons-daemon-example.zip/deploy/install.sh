#!/bin/bash

apt-get update
apt-get install jsvc

mkdir -p /opt/service
cp commons-daemon-1.0.15.jar /opt/service/

mkdir -p /opt/service/example
cp service.sh /opt/service/example
cp commons-daemon-example-1.0.jar /opt/service/example
