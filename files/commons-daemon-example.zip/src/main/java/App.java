import org.apache.commons.daemon.Daemon;
import org.apache.commons.daemon.DaemonContext;
import org.apache.commons.daemon.DaemonInitException;

/**
 * Created by guzhijun on 2016/11/24.
 */
public class App implements Daemon {
    private ThreadExample threadExample = new ThreadExample();

    public void init(DaemonContext var1) throws DaemonInitException, Exception {
        System.out.println("init method begin");
        System.out.println("init method end");
    }

    public void start() throws Exception {
        System.out.println("start method begin");
        threadExample.start();
        System.out.println("start method end");
    }

    public void stop() throws Exception {
        System.out.println("stop method begin");
        threadExample.running = false;
        while (threadExample.isAlive()) {
            System.out.println("wait threadExample stop");
            try {
                Thread.sleep(1000);
            } catch (Exception ignore) {
            }
        }
        System.out.println("stop method end");
    }

    public void destroy() {
        System.out.println("destroy method begin");
        System.out.println("destroy method end");
    }
}
