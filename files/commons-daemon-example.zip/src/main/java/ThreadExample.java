/**
 * Created by guzhijun on 2016/11/24.
 */
public class ThreadExample extends Thread {
    public boolean running = false;

    public ThreadExample() {
        this.setName("ThreadExample");
    }

    public void run() {
        if (!running) {
            running = true;
            while (running) {
                System.out.println("ThreadExample run sleep 1000ms");
                try {
                    Thread.sleep(1000);
                } catch (Exception ignore) {
                }
            }
        }
    }
}
