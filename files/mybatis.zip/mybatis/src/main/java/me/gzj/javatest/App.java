package me.gzj.javatest;

import me.gzj.javatest.configuration.AppConfiguration;
import me.gzj.javatest.dao.IKVDao;
import me.gzj.javatest.entity.KV;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws Exception
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
        IKVDao kvDao = context.getBean(IKVDao.class);
        kvDao.insertKV(new KV("k11", "👌"));
        System.out.println(kvDao.selectKV(11));
    }
}
