package me.gzj.javatest.dao;

import me.gzj.javatest.entity.KV;
import org.apache.ibatis.annotations.Param;

/**
 * Created by ghijnuuz on 2017/7/28.
 */
public interface IKVDao {
    void insertKV(KV kv);

    KV selectKV(@Param("id") int id);
}
