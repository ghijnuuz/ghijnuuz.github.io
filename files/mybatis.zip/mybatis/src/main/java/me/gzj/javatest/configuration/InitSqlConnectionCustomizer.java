package me.gzj.javatest.configuration;

import com.mchange.v2.c3p0.AbstractConnectionCustomizer;

import java.sql.Connection;
import java.sql.Statement;

/**
 * Created by ghijnuuz on 2017/7/28.
 */
public class InitSqlConnectionCustomizer extends AbstractConnectionCustomizer {
    @Override
    public void onCheckOut(Connection c, String parentDataSourceIdentityToken) throws Exception {
        String initSql = "set names utf8mb4;";
        Statement stmt = null;
        try {
            stmt = c.createStatement();
            stmt.executeUpdate(initSql);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }
}
