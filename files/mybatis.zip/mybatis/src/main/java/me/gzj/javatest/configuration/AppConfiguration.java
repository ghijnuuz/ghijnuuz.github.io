package me.gzj.javatest.configuration;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.util.ArrayList;

/**
 * Created by ghijnuuz on 2017/7/27.
 */
@Configuration
@ComponentScan(basePackages = "me.gzj.javatest")
@PropertySource("classpath:config.properties")
public class AppConfiguration {
    @Bean
    @Autowired
    public DataSource dataSource(Environment environment) throws Exception {
        //region c3p0 pool
//        ComboPooledDataSource dataSource = new ComboPooledDataSource();
//        dataSource.setDriverClass(environment.getProperty("JDBC.driver"));
//        dataSource.setJdbcUrl(environment.getProperty("JDBC.url"));
//        dataSource.setUser(environment.getProperty("JDBC.username"));
//        dataSource.setPassword(environment.getProperty("JDBC.password"));
//        dataSource.setConnectionCustomizerClassName(environment.getProperty("JDBC.connectionCustomizer"));
        // connect poll config ToDo
        //endregion

        //region dbcp pool
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(environment.getProperty("JDBC.driver"));
        dataSource.setUrl(environment.getProperty("JDBC.url"));
        dataSource.setUsername(environment.getProperty("JDBC.username"));
        dataSource.setPassword(environment.getProperty("JDBC.password"));
        dataSource.setConnectionInitSqls(new ArrayList<String>() {{
            add(environment.getProperty("JDBC.onnectionInitSqls"));
        }});
        // connect poll config ToDo
        //endregion

        return dataSource;
    }

    @Bean
    @Autowired
    public SqlSessionFactoryBean sqlSessionFactory(DataSource dataSource) {
        SqlSessionFactoryBean result = new SqlSessionFactoryBean();
        result.setDataSource(dataSource);
        ClassPathResource resource = new ClassPathResource("mybatis/mybatis-config.xml");
        result.setConfigLocation(resource);
        return result;
    }

    @Bean
    public MapperScannerConfigurer mapperScannerConfigurer() {
        MapperScannerConfigurer result = new MapperScannerConfigurer();
        result.setBasePackage("me.gzj.javatest.dao");
        result.setSqlSessionFactoryBeanName("sqlSessionFactory");
        return result;
    }

    @Bean
    @Autowired
    public DataSourceTransactionManager transactionManager(DataSource dataSource) {
        DataSourceTransactionManager result = new DataSourceTransactionManager();
        result.setDataSource(dataSource);
        return result;
    }
}
