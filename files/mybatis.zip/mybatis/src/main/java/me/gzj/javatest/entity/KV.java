package me.gzj.javatest.entity;

/**
 * Created by ghijnuuz on 2017/4/5.
 */
public class KV {
    public KV() {
    }

    public KV(String k, String v) {
        this.k = k;
        this.v = v;
    }

    public int id;
    public String k;
    public String v;

    @Override
    public String toString() {
        return String.format("[KV] id:%d, k:%s, v:%s", id, k, v);
    }
}
